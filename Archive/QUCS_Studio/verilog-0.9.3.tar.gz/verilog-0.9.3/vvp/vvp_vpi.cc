
#include <cstdarg>
#include "vpi_user.h"


void vvp_vpi_init()
{
}

