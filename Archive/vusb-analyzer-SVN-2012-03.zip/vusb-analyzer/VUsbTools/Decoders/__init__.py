#
# VUsbTools.Decoders
# Micah Elizabeth Scott <micah@vmware.com>
#
# Files here will automatically be loaded as class decoders.
# See Decode.DecoderFactory for more information.
#
