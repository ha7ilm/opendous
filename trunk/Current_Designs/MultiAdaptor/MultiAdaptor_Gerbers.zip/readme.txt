File Format: Gerber RS-274-X
Plot Origin: Absolute

	MultiAdaptor-SOIC-SSOP-SOT23-SC70-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	MultiAdaptor-SOIC-SSOP-SOT23-SC70-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	MultiAdaptor-SOIC-SSOP-SOT23-SC70-Front.gtl		: Top/Front Copper Layer
	MultiAdaptor-SOIC-SSOP-SOT23-SC70-Back.gbl		: Bottom/Back Copper Layer
	MultiAdaptor-SOIC-SSOP-SOT23-SC70-Mask_Back.gbs		: Bottom/Back Layer Green Solder Mask
	MultiAdaptor-SOIC-SSOP-SOT23-SC70-SilkS_Back.gbo	: Bottom/Back Layer White Silkscreen
	MultiAdaptor-SOIC-SSOP-SOT23-SC70-PCB_Edges.gbr		: PCB Edge Outline

Drill File: MultiAdaptor-SOIC-SSOP-SOT23-SC70.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 44
	Notes:  - No axis mirroring and only standard vias

Design Notes:
	- Design Size: 0.8" x 1.4"
	- Design Detail: 8mil-8mil-20mil Trace-Clearance-Minimum_Drill
	- MultiAdaptor-SOIC-SSOP-SOT23-SC70-Drill_Sheet.pho Gerber shows all drill locations
