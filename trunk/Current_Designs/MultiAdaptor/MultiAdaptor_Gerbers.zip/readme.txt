File Format: Gerber RS-274-X
Plot Origin: Absolute

	MultiAdaptor-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	MultiAdaptor-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	MultiAdaptor-Front.gtl		: Top/Front Copper Layer
	MultiAdaptor-Back.gbl		: Bottom/Back Copper Layer
	MultiAdaptor-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	MultiAdaptor-SilkS_Back.gtb	: Bottom/Back Layer White Silkscreen

	MultiAdaptor-PCB_Edges.oln	: PCB Edge Outline


Drill File: MultiAdaptor.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Suppress Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 38
	Notes:	- No axis mirroring
		- Standard Vias Only
		- All holes are plated
