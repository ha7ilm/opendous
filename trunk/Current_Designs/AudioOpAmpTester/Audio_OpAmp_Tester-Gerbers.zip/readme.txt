File Format: Gerber RS-274-X
Plot Origin: Absolute

	Audio_OpAmp_Tester-SoldP_Front.gtp	: Top/Front Solder Paste Stencil

	Audio_OpAmp_Tester-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Audio_OpAmp_Tester-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Audio_OpAmp_Tester-Front.gtl		: Top/Front Copper Layer
	Audio_OpAmp_Tester-Back.gbl		: Bottom/Back Copper Layer
	Audio_OpAmp_Tester-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	Audio_OpAmp_Tester-PCB_Edges.oln	: PCB Edge Outline

Drill File: Audio_OpAmp_Tester.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : None, Keep Zeros
	Type : ASCII
	Drill Holes (Pads and Vias): 205
	Notes:  - Minimal Header
		- No axis mirroring and only standard vias
		- All holes are plated
		- Design is 8mil-8mil-20mil Trace-Clearance-Minimum_Drill
