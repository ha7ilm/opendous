File Format: Gerber RS-274-X
Plot Origin: Absolute

	Opendous_FT2232H_JTAG-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Opendous_FT2232H_JTAG-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Opendous_FT2232H_JTAG-Front.gtl		: Top/Front Copper Layer
	Opendous_FT2232H_JTAG-Back.gbl		: Bottom/Back Copper Layer
	Opendous_FT2232H_JTAG-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	Opendous_FT2232H_JTAG-SilkS_Back.gbo	: Bottom/Back Layer White Silkscreen
	Opendous_FT2232H_JTAG-PCB_Edges.gbr	: PCB Edge Outline (Info Only)

Drill File: Opendous_FT2232H_JTAG.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 171
	Notes:  - No axis mirroring
		- Only standard vias are used
		- Opendous_FT2232H_JTAG-Drill_Sheet.pho shows all drill locations
