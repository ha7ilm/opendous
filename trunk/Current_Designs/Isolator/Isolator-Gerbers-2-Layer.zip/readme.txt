File Format: Gerber RS-274-X
Plot Origin: Absolute

	Isolator-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Isolator-Mask_Front.gts		: Top/Front Layer Green Solder Mask
	Isolator-Front.gtl		: Top/Front Copper Layer
	Isolator-Back.gbl		: Bottom/Back Copper Layer
	Isolator-Mask_Back.gbs		: Bottom/Back Layer Green Solder Mask
	Isolator-SilkS_Back.gbo		: Bottom/Back Layer White Silkscreen
	Isolator-PCB_Edges.gbr		: PCB Edge Outline

Drill File: Isolator.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 62
	Notes:  - No axis mirroring and only standard vias

Design Notes:
	- Design Size: 1" x 1"
	- Design Detail: 8mil-8mil-20mil Trace-Clearance-Minimum_Drill
	- Isolator-Drill_Sheet.pho Gerber shows all drill locations
