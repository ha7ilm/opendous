File Format: Gerber RS-274-X
Plot Origin: Absolute

	USB_Protocol_Analyzer_Front-End-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	USB_Protocol_Analyzer_Front-End-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	USB_Protocol_Analyzer_Front-End-Front.gtl	: Top/Front Copper Layer
	USB_Protocol_Analyzer_Front-End-Back.gbl	: Bottom/Back Copper Layer
	USB_Protocol_Analyzer_Front-End-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	USB_Protocol_Analyzer_Front-End-PCB_Edges.oln	: PCB Edge Outline

Drill File: USB_Protocol_Analyzer_Front-End.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : None (Keep Zeros)
	Type : ASCII
	Drill Holes (Pads and Vias): 80
	Notes:  - No axis mirroring and only standard plated vias
