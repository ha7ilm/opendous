/*
  Modified for ADS1298 Communication By Opendous Inc.
  www.opendous.org/BioSensorPlatform
  Last Edit: 2012-04-29 By m @ Opendous Inc.

  Based on LUFA Demo Copyright 2010 Dean Camera (dean [at] fourwalledcubicle [dot] com)

  Notes:
    - it is important that MISO(DIN) starts off low
    - SDATAC command must be sent before register read/write commands can be used
    - Connections
        ADS1298 <=> ADS1298
        VCC <=> VCC(3.3V)
        GND <=> GND
        DIN <=> PB2
        nCS <=> PB0
        SCLK <=> PB1
        DOUT <=> PB3
        nRST <=> PD0
        START <=> VCC(3.3V)
        nPWDN <=> PD1
        nDRDY <=> PD2

        LED <=> PD6
    - ADS1298-related code is at lines 189-240 and 601-761

  TODO:
    - 

  Permission to use, copy, modify, distribute, and sell this
  software and its documentation for any purpose is hereby granted
  without fee, provided that the above copyright notice appear in
  all copies and that both that the copyright notice and this
  permission notice and warranty disclaimer appear in supporting
  documentation, and that the name of the author not be used in
  advertising or publicity pertaining to distribution of the
  software without specific, written prior permission.

  The author disclaim all warranties with regard to this
  software, including all implied warranties of merchantability
  and fitness.  In no event shall the author be liable for any
  special, indirect or consequential damages or any damages
  whatsoever resulting from loss of use, data or profits, whether
  in an action of contract, negligence or other tortious action,
  arising out of or in connection with the use or performance of
  this software.
*/

/** \file
 *
 *  Main source file for the USBtoSerial project. This file contains the main tasks of
 *  the demo and is responsible for the initial application hardware configuration.
 */

#include "USBVirtualSerial-ADS1298.h"

//static FILE USBstdio;
 static FILE USBstdio = FDEV_SETUP_STREAM(sendData, getData, _FDEV_SETUP_RW);



volatile uint8_t channelData[27];
volatile uint32_t status = 0;



#define NOP do { __asm__ __volatile__ ("nop"); } while (0)


// Defines used for SPI nCS Pins
#define CS_PIN			PB0
#define CS_PORT			PORTB
#define CS_DDR			DDRB

#define CS_HIGH			CS_PORT |= (1 << CS_PIN);
#define CS_LOW			CS_PORT &= ~(1 << CS_PIN);


#define MOSI_PIN		PB2
#define MOSI_PORT		PORTB
#define MOSI_DDR		DDRB

#define MOSI_HIGH		MOSI_PORT |= (1 << MOSI_PIN);
#define MOSI_LOW		MOSI_PORT &= ~(1 << MOSI_PIN); SPCR = ((1 << SPE) | (SPI_MODE_MASTER | SPI_SCK_LEAD_RISING | SPI_SAMPLE_TRAILING | SPI_SPEED_FCPU_DIV_4 | SPI_ORDER_MSB_FIRST)); SPSR &= ~(1 << SPI2X);


#define RESET_PIN		PD0
#define RESET_PORT		PORTD
#define RESET_DDR		DDRD

#define RESET_HIGH		RESET_PORT |= (1 << RESET_PIN);
#define RESET_LOW		RESET_PORT &= ~(1 << RESET_PIN);


#define PWDN_PIN		PD1
#define PWDN_PORT		PORTD
#define PWDN_DDR		DDRD

#define PWDN_HIGH		PWDN_PORT |= (1 << PWDN_PIN);
#define PWDN_LOW		PWDN_PORT &= ~(1 << PWDN_PIN);


#define START_PIN		PD4
#define START_PORT		PORTD
#define START_DDR		DDRD

#define START_HIGH		START_PORT |= (1 << START_PIN);
#define START_LOW		START_PORT &= ~(1 << START_PIN);


#define LED_PIN			PD6
#define LED_PORT			PORTD
#define LED_DDR			DDRD



#define BUFFER_PIN		PC6
#define BUFFER_PORT		PORTC
#define BUFFER_DDR		DDRC

#define BUFFER_HIGH		BUFFER_PORT |= (1 << BUFFER_PIN);
#define BUFFER_LOW		BUFFER_PORT &= ~(1 << BUFFER_PIN);



// DRDY should be an interrupt pin
#define DRDY_PIN		PD2
#define DRDY_PORT		PORTD
#define DRDY_DDR		DDRD
#define DRDY_INPUTP			PIND
#define DRDY_STATE		((DRDY_INPUTP & (1 << DRDY_PIN)) ^ (1 << DRDY_PIN))





/** Circular buffer to hold data from the host before it is sent to the device via the serial port. */
RingBuff_t HostToDevice_Buffer;

/** Circular buffer to hold data from the serial port before it is sent to the host. */
RingBuff_t DeviceToHost_Buffer;

/** LUFA CDC Class driver interface configuration and state information. This structure is
 *  passed to all CDC Class driver functions, so that multiple instances of the same class
 *  within a device can be differentiated from one another.
 */
USB_ClassInfo_CDC_Device_t VirtualSerial_CDC_Interface =
	{
		.Config =
			{
				.ControlInterfaceNumber         = 0,

				.DataINEndpointNumber           = CDC_TX_EPNUM,
				.DataINEndpointSize             = CDC_TXRX_EPSIZE,
				.DataINEndpointDoubleBank       = false,

				.DataOUTEndpointNumber          = CDC_RX_EPNUM,
				.DataOUTEndpointSize            = CDC_TXRX_EPSIZE,
				.DataOUTEndpointDoubleBank      = false,

				.NotificationEndpointNumber     = CDC_NOTIFICATION_EPNUM,
				.NotificationEndpointSize       = CDC_NOTIFICATION_EPSIZE,
				.NotificationEndpointDoubleBank = false,
			},
	};

/** Main program entry point. This routine contains the overall program flow, including initial
 *  setup of all components and the main program loop.
 */
int main(void)
{

	uint8_t i = 0;

	SetupHardware();


	for (i = 0; i < 27; i++) {
		channelData[i] = 0;
	}


	LEDs_SetAllLEDs(LEDMASK_USB_NOTREADY);
	sei();

	puts_P(PSTR(ESC_FG_CYAN "\r\nADS1298 Communication Interface Running.\r\n" ESC_FG_WHITE));

	// Reset the ADS1298
	RESET_LOW;
	PWDN_LOW;
	_delay_ms(1);
	CS_HIGH;
	PWDN_HIGH;
	START_HIGH;
	RESET_HIGH;
	_delay_ms(1000); // need 1s for ADS1298 to settle after Reset - "SETTING THE DEVICE FOR BASIC DATA CAPTURE"

	// issue reset pulse
	RESET_LOW;
	_delay_us(1);
	RESET_HIGH;
	_delay_ms(1000);

	// send SDATAC command so that registers can be written
	CS_LOW;
	SPI_SendByte(0x11);
	MOSI_LOW;
	CS_HIGH;
	_delay_us(2);

	// write CONFIG
	CS_LOW;
	SPI_SendByte(0x41); // write registers starting from 0x1
	MOSI_LOW;
	SPI_SendByte(0x0A); // write 11 registers
	MOSI_LOW;
	SPI_SendByte(0x04); // CONFIG1 = 0b00000100 = 0x04 --> 1kSPS data rate
	MOSI_LOW;
	SPI_SendByte(0x13); // CONFIG2 = 0b00010011 = 0x05 --> Internal Test Signal at DC
	MOSI_LOW;
	SPI_SendByte(0xC0); // CONFIG3 = 0b11000000 = 0xC0 --> REFBUF enabled
	MOSI_LOW;
	SPI_SendByte(0x0C); // CH1SET = 0b00001100 = 0x0C --> CH1 Gain=1, Connected to Temperature Sensor
	MOSI_LOW;
	SPI_SendByte(0x11); // CH2SET = 0b00010001 = 0x11 --> CH2 Gain=1, Inputs Shorted
	MOSI_LOW;
	SPI_SendByte(0x15); // CH3SET = 0b00010101 = 0x15 --> CH3 Gain=1, Test Signal
	MOSI_LOW;
	SPI_SendByte(0x13); // CH4SET = 0b00010011 = 0x13 --> CH4 Gain=1, MVDD Supply
	MOSI_LOW;
	SPI_SendByte(0x10); // CH5SET = 0b00010000 = 0x10 --> CH5 Gain=1, Normal Electrode Input
	MOSI_LOW;
	SPI_SendByte(0x10); // CH6SET = 0b00010000 = 0x10 --> CH6 Gain=1, Normal Electrode Input
	MOSI_LOW;
	SPI_SendByte(0x10); // CH7SET = 0b00010000 = 0x10 --> CH7 Gain=1, Normal Electrode Input
	MOSI_LOW;
	SPI_SendByte(0x10); // CH8SET = 0b00010000 = 0x10 --> CH8 Gain=1, Normal Electrode Input
	MOSI_LOW;
	CS_HIGH;





    
	RingBuffer_InitBuffer(&HostToDevice_Buffer);
	RingBuffer_InitBuffer(&DeviceToHost_Buffer);

	LEDs_SetAllLEDs(LEDMASK_USB_NOTREADY);
	sei();

	// this for(...) loop is the main difference between the standard USBVirtualSerial
	// and this _MultipleReads version.  Timer is not used and throughput is
	// lower but all available bytes are accessed from the OUT endpoint.
	for (;;)
	{

		// Read bytes from the USB OUT endpoint into the local data buffer
		for (uint8_t DataBytesRem = CDC_Device_BytesReceived(&VirtualSerial_CDC_Interface); DataBytesRem != 0; DataBytesRem--) {
			// Only try to read in bytes from the CDC interface if the transmit buffer is not full
			if (!(RingBuffer_IsFull(&HostToDevice_Buffer)))
			{
				int16_t ReceivedByte = CDC_Device_ReceiveByte(&VirtualSerial_CDC_Interface);

				// Read bytes from the USB OUT endpoint into the local data buffer
				if (!(ReceivedByte < 0))
					RingBuffer_Insert(&HostToDevice_Buffer, ReceivedByte);
			}
		}

		// Read bytes from the local data buffer into the USB IN endpoint
		RingBuff_Count_t BufferCount = RingBuffer_GetCount(&DeviceToHost_Buffer);
		while (BufferCount--)
			CDC_Device_SendByte(&VirtualSerial_CDC_Interface, RingBuffer_Remove(&DeviceToHost_Buffer));

		CDC_Device_USBTask(&VirtualSerial_CDC_Interface);
		USB_USBTask();

		MainTask();
	}

}

/** Configures the board hardware and chip peripherals for the demo's functionality. */
void SetupHardware(void)
{
	/* Disable watchdog if enabled by bootloader/fuses */
	MCUSR &= ~(1 << WDRF);
	wdt_disable();

	/* Disable clock division */
	clock_prescale_set(clock_div_2);

	/* disable JTAG to allow corresponding pins to be used - PF4, PF5, PF6, PF7 */
	/* TODO - remove this if you want to use your JTAG debugger to debug this firmware */
	#if (defined(__AVR_AT90USB1287__) || defined(__AVR_AT90USB647__) ||  \
			defined(__AVR_AT90USB1286__) || defined(__AVR_AT90USB646__) ||  \
			defined(__AVR_ATmega16U4__)  || defined(__AVR_ATmega32U4__) ||  \
			defined(__AVR_ATmega32U6__))
		// note the JTD bit must be written twice within 4 clock cycles to disable JTAG
		// you must also set the IVSEL bit at the same time, which requires IVCE to be set first
		// port pull-up resistors are enabled - PUD(Pull Up Disable) = 0
		MCUCR = (1 << JTD) | (1 << IVCE) | (0 << PUD);
		MCUCR = (1 << JTD) | (0 << IVSEL) | (0 << IVCE) | (0 << PUD);
	#endif

	/* Hardware Initialization */
	/* enable Ports based on which IC is being used */
	/* For more information look over the corresponding AVR's datasheet in the
		'I/O Ports' Chapter under subheading 'Ports as General Digital I/O' */
	#if (defined(__AVR_AT90USB162__) || defined(__AVR_AT90USB82__) || \
			defined(__AVR_ATmega16U2__) || defined(__AVR_ATmega32U2__))
		DDRD = 0;
		PORTD = 0;
		DDRB = 0;
		PORTB = 0;
		DDRC = 0;
		PORTC |= (0 << PC2) | (0 << PC4) | (0 << PC5) | (0 << PC6) | (0 << PC7); //only PC2,4,5,6,7 are pins
		// be careful using PortC as PC0 is used for the Crystal and PC1 is nRESET
	#endif

	#if (defined(__AVR_ATmega16U4__)  || defined(__AVR_ATmega32U4__))
		DDRD = 0;
		PORTD = 0;
		DDRB = 0;
		PORTB = 0;
		DDRC = 0;
		PORTC = (0 << PC6) | (0 << PC7); //only PC6,7 are pins
		DDRE = 0;
		PORTE = (0 << PE2) | (0 << PE6); //only PE2,6 are pins
		DDRF = 0;
		PORTF = (0 << PF0) | (0 << PF1) | (0 << PF4) | (0 << PF5) | (0 << PF6) | (0 << PF7); // only PF0,1,4,5,6,7 are pins
	#endif

	#if (defined(__AVR_AT90USB1287__) || defined(__AVR_AT90USB647__) ||  \
			defined(__AVR_AT90USB1286__) || defined(__AVR_AT90USB646__) ||  \
			defined(__AVR_ATmega32U6__))
		DDRA = 0;
		PORTA = 0;
		DDRB = 0;
		PORTB = 0;
		DDRC = 0;
		PORTC = 0;
		DDRD = 0;
		PORTD = 0;
		DDRE = 0;
		PORTE = 0;
		DDRF = 0;
		PORTF = 0;
		#if (BOARD == BOARD_MICROPENDOUS)
		// set PortB pin 1 to an output as it connects to an LED on the Micropendous
		DDRB |= (1 << PB1);
		// Set PE4=1 to disable external SRAM, PE6=0 to disable TXB0108, PE7=1 to select USB-B connector
		DDRE |= ((1 << PE4) | (1 << PE6) | (1 << PE7));
		PORTE |= ((1 << PE4) | (1 << PE7));
		PORTE &= ~(1 << PE6);
		#else // other boards such as the Micropendous3 or Micropendous4
		// Set PE6=1 to disable external SRAM
		DDRE |= (1 << PE6);
		PORTE |= (1 << PE6);
		#endif
	#endif

	/* Hardware Initialization */
	SerialStream_Init(9600, false); // for debugg messages over UART

	MOSI_DDR |= (1 << MOSI_PIN);

	// SPI Mode 1 (CPOL=0,CPHA=1)(Setup (Rising), Sample (Falling)) with 2MHz clock per ADS1298 Datasheet "TIMING CHARACTERISTICS"
	SPI_Init((SPI_MODE_MASTER | SPI_SCK_LEAD_RISING | SPI_SAMPLE_TRAILING | SPI_SPEED_FCPU_DIV_4 | SPI_ORDER_MSB_FIRST));
	MOSI_PORT &= ~(1 << MOSI_PIN);

	// Set ChipSelect/Reset/Powerdown pins to output and set to 1/High as they are active-low signals
	CS_DDR |= (1 << CS_PIN);
	CS_HIGH;
	RESET_DDR |= (1 << RESET_PIN);
	RESET_LOW;
	PWDN_DDR |= (1 << PWDN_PIN);
	PWDN_LOW;
	
	// Set Start pin to output and set to 0/Low as it is an active-high signal
	START_DDR |= (1 << START_PIN);
	START_LOW;

	// DRDY is an input
	DDRD &= ~(1 << PD2);
	PORTD |= (1 << PD2);

	// LED on PD6
	DDRD |= (1 << PD6);
	PORTD |= (1 << PD6);


	// Disable LVC125 buffer on PC6
	DDRC |= (1 << PC6);
	PORTC |= (1 << PC6);
	BUFFER_HIGH;


	LEDs_Init();
	Buttons_Init();
	SELECT_USB_B;
	USB_Init();

	/* Start the flush timer so that overflows occur rapidly to push received bytes to the USB interface */
	TCCR0B = (1 << CS02);
}

/** Event handler for the library USB Connection event. */
void EVENT_USB_Device_Connect(void)
{
	LEDs_SetAllLEDs(LEDMASK_USB_ENUMERATING);
}

/** Event handler for the library USB Disconnection event. */
void EVENT_USB_Device_Disconnect(void)
{
	LEDs_SetAllLEDs(LEDMASK_USB_NOTREADY);
}

/** Event handler for the library USB Configuration Changed event. */
void EVENT_USB_Device_ConfigurationChanged(void)
{
	bool ConfigSuccess = true;

	ConfigSuccess &= CDC_Device_ConfigureEndpoints(&VirtualSerial_CDC_Interface);

	LEDs_SetAllLEDs(ConfigSuccess ? LEDMASK_USB_READY : LEDMASK_USB_ERROR);
}

/** Event handler for the library USB Control Request reception event. */
void EVENT_USB_Device_ControlRequest(void)
{
	CDC_Device_ProcessControlRequest(&VirtualSerial_CDC_Interface);
}


/** Event handler for the CDC Class driver Line Encoding Changed event.
 *
 *  \param[in] CDCInterfaceInfo  Pointer to the CDC class interface configuration structure being referenced
 */
void EVENT_CDC_Device_LineEncodingChanged(USB_ClassInfo_CDC_Device_t* const CDCInterfaceInfo)
{
	/* TODO - Use Virtual Serial Port settings to control your application.
		Think of this as another data channel.  Use it for control/status messaging.
		Leave the data channel (MainTask putchar/getchar) for data only.
	*/

	switch (CDCInterfaceInfo->State.LineEncoding.ParityType)
	{
		case CDC_PARITY_Odd:
			// do something here
			break;
		case CDC_PARITY_Even:
			// and/or maybe here
			break;
		case CDC_PARITY_None:
			// maybe something here
			break;
		case CDC_PARITY_Mark:
			// something here could work
			break;
		case CDC_PARITY_Space:
			// you guessed it, something could go here
			break;
	}


	switch (CDCInterfaceInfo->State.LineEncoding.CharFormat)
	{
		case CDC_LINEENCODING_OneStopBit:
			// do something here
			break;
		case CDC_LINEENCODING_OneAndAHalfStopBits:
			// and/or maybe do something here
			break;
		case CDC_LINEENCODING_TwoStopBits:
			// something here could work
			break;
	}


	switch (CDCInterfaceInfo->State.LineEncoding.DataBits)
	{
		case 6:
			// possibly something
			break;
		case 7:
			// possibly something
			break;
		case 8:
			// possibly something
			break;
	}


	switch (CDCInterfaceInfo->State.LineEncoding.BaudRateBPS)
	{
		case 9600:
			// possibly something
			break;
		case 14400:
			// possibly something
			break;
		case 19200:
			// possibly something
			break;
		case 38400:
			// possibly something
			break;
		case 57600:
			// possibly something
			break;
		case 115200:
			// possibly something
			break;
	}

}


/** CDC class driver event for a control line state change on a CDC interface. This event fires each time the host requests a
 *  control line state change (containing the virtual serial control line states, such as DTR). The new control line states
 *  are available in the ControlLineStates.HostToDevice value inside the CDC interface structure passed as a parameter, set as
 *  a mask of CDC_CONTROL_LINE_OUT_* masks.  1 is for 'Set'(Low) and 0 is for 'Clear'(High) as these are active low signals.
 *  \param[in,out] CDCInterfaceInfo  Pointer to a structure containing a CDC Class configuration and state
*/
void EVENT_CDC_Device_ControLineStateChanged(USB_ClassInfo_CDC_Device_t* const CDCInterfaceInfo)
{
	/* TODO - Use Virtual Serial Port settings to control your application.
		Think of this as another data channel.  Use it for control/status messaging.
		Leave the data channel (MainTask putchar/getchar) for data only.
	*/

	if ((CDCInterfaceInfo->State.ControlLineStates.HostToDevice) & CDC_CONTROL_LINE_OUT_RTS) {
		// Host has set the RTS line
	} else {
		// Host has cleared the RTS line
	}

	if ((CDCInterfaceInfo->State.ControlLineStates.HostToDevice) & CDC_CONTROL_LINE_OUT_DTR) {
		// Host has set the DTR line
	} else {
		// Host has cleared the DTR line
	}
}


/* Use this function to make sure data exists.
	Need this function as RingBuff will crash if getData is called on
	an empty buffer
*/
uint8_t haveData(void) {
	return (uint8_t)(!RingBuffer_IsEmpty(&HostToDevice_Buffer));
}

/* In order to use printf functions, need a function that will send data over
	the USB Virtual Serial Port link
	return 0 on success, else failure and ensure binary compatibility
*/
static int sendData(char c, FILE *stream) {
	// most terminals require \r\n
	// however, do not include this conversion as it will break binary transfers 
	//if (c == '\n') {
	//	sendData('\r', stream);
	//}
	if (!RingBuffer_IsFull(&DeviceToHost_Buffer)) {
		RingBuffer_Insert(&DeviceToHost_Buffer, (uint8_t)c);
		return 0;
	} else {
		return 1;
	}
}

/* Function to receive data from the USB Virtual Serial Port link */
int getData(FILE *__stream) {
	//if (something) return _FDEV_ERR; // cannot implement as GetElement has no error condition
	if (haveData() == 0) {
		return _FDEV_EOF;
	}
	return (int)RingBuffer_Remove(&HostToDevice_Buffer);
}



/* MainTask will run once initialization is complete */
/* TODO - place your application code here */
void MainTask(void)
{
	int tempInt = 0;	// temporary storage - integer (16-bit)
	uint8_t i = 0;
	uint8_t baseIdx = 0;
	uint8_t temp1 = 0;
	uint8_t temp2 = 0;
	uint8_t temp3 = 0;
	uint8_t temp4 = 0;
	uint8_t temp5 = 0;
	uint32_t temp6 = 0;


	if (~PIND & (1 << PIND2)) {
		// DRDY signal is low
		PORTD &= ~(1 << PD6);

		// data is ready, so receive it (24-bit status + 8 * 24-bit channel data)
		MOSI_LOW;
		CS_LOW;
		SPI_SendByte(0x12); // RDATA command
		MOSI_LOW;
		_delay_us(2);

		// read the 27bytes (216 bits) of data; 24-bit status + 8 * 24-bit channels
		for (i = 0; i < 27; i++) {
			channelData[i] = SPI_ReceiveByte();
		}
		MOSI_LOW;
		CS_HIGH;

	} else {
		// DRDY signal is high
		PORTD |= (1 << PD6);
	}


	// If the host has sent data then process it
	while (haveData()) {	// need to check that data exists before processing it
		// get data received over the USB Virtual Serial Port
		tempInt = fgetc(&USBstdio);

		// send back data received over the USB Virtual Serial Port
		fputc(tempInt, &USBstdio);


		if (tempInt == '1') {
			baseIdx = 3;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel1=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '2') {
			baseIdx = 6;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel2=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '3') {
			baseIdx = 9;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel3=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '4') {
			baseIdx = 12;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel4=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '5') {
			baseIdx = 15;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel5=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '6') {
			baseIdx = 18;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel6=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '7') {
			baseIdx = 21;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel7=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '8') {
			baseIdx = 24;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nChannel8=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}

		if (tempInt == '0') {
			baseIdx = 0;
			temp6 = (uint32_t)( (((uint32_t)channelData[baseIdx]) << 16) + (((uint32_t)channelData[(baseIdx+1)]) << 8) + ((uint32_t)channelData[(baseIdx+2)]) );
			fprintf_P(&USBstdio, PSTR("\r\nStatus=0x%06lX\r\n" ESC_FG_WHITE), temp6);
		}


		if (tempInt == 'r') {
			fprintf_P(&USBstdio, PSTR("\r\nRegisters 0-9=   " ESC_FG_WHITE));
			CS_LOW;
			MOSI_LOW;
			SPI_SendByte(0x20);
			MOSI_LOW;
			SPI_SendByte(0x08);
			MOSI_LOW;
			_delay_us(2);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			CS_HIGH;
			MOSI_LOW;
			fprintf_P(&USBstdio, PSTR("\r\n" ESC_FG_WHITE));
		}


		if (tempInt == 't') {
			fprintf_P(&USBstdio, PSTR("\r\nRegisters A-12=  " ESC_FG_WHITE));
			CS_LOW;
			MOSI_LOW;
			SPI_SendByte(0x2A);
			MOSI_LOW;
			SPI_SendByte(0x08);
			MOSI_LOW;
			_delay_us(2);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			CS_HIGH;
			MOSI_LOW;
			fprintf_P(&USBstdio, PSTR("\r\n" ESC_FG_WHITE));
		}


		if (tempInt == 'y') {
			fprintf_P(&USBstdio, PSTR("\r\nRegisters 13-19= " ESC_FG_WHITE));
			CS_LOW;
			MOSI_LOW;
			SPI_SendByte(0x33);
			MOSI_LOW;
			SPI_SendByte(0x06);
			MOSI_LOW;
			_delay_us(2);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			temp1 = SPI_ReceiveByte(); fprintf_P(&USBstdio, PSTR("%02x," ESC_FG_WHITE), temp1);
			CS_HIGH;
			MOSI_LOW;
			fprintf_P(&USBstdio, PSTR("\r\n" ESC_FG_WHITE));
		}


	}

}
