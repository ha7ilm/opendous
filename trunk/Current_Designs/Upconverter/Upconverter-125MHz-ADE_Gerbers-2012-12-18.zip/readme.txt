File Format: Gerber RS-274-X
Plot Origin: Absolute

	Upconverter-125MHz-ADE-SoldP_Front.gtp	: Top/Front Layer Solder Paste Stencil

	Upconverter-125MHz-ADE-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Upconverter-125MHz-ADE-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Upconverter-125MHz-ADE-Front.gtl	: Top/Front Copper Layer
	Upconverter-125MHz-ADE-Back.gbl		: Bottom/Back Copper Layer
	Upconverter-125MHz-ADE-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask

	Upconverter-125MHz-ADE-PCB_Edges.gbr	: PCB Edge Outline


Drill File: Upconverter-125MHz-ADE.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Suppress Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 408
	Notes:	- No axis mirroring
		- Standard Vias Only
		- All holes are plated
		- There are two SolderPaste versions, one for
		  USB-microB, and one for USB-B. Select one.
