File Format: Gerber RS-274-X
Plot Origin: Absolute

	Opennect_Position_System-SoldP_Front.gtp	: Top/Front Solder Paste Stencil

	Opennect_Position_System-SilkS_Front.gto	: Top/Front Layer Silkscreen
	Opennect_Position_System-Mask_Front.gts		: Top/Front Layer Solder Mask
	Opennect_Position_System-Front.gtl		: Top/Front Copper Layer
	Opennect_Position_System-Back.gbl		: Bottom/Back Copper Layer
	Opennect_Position_System-Mask_Back.gbs		: Bottom/Back Layer Solder Mask
	Opennect_Position_System-PCB_Edges.oln		: PCB Edge Outline

Drill File: Opennect_Position_System.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : None
	Type : ASCII
	Drill Holes (Pads and Vias): 58
	Notes:  - No axis mirroring and only standard vias
		- All holes are plated
		- Minimal Header
