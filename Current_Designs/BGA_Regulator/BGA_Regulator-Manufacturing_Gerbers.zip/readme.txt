File Format: Gerber RS-274-X
Plot Origin: Absolute

	BGA_Regulator-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	BGA_Regulator-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	BGA_Regulator-Front.gtl		: Top/Front Copper Layer
	BGA_Regulator-Back.gbl		: Bottom/Back Copper Layer
	BGA_Regulator-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	BGA_Regulator-SilkS_Back.gbo	: Bottom/Back Layer White Silkscreen
	BGA_Regulator-PCB_Edges.oln	: PCB Edge Outline (Info Only)


Drill File: BGA_Regulator.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 24
	Notes:  - No axis mirroring and only standard vias
