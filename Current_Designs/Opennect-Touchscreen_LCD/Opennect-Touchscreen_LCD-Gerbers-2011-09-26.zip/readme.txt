File Format: Gerber RS-274-X
Plot Origin: Absolute

	Opennect-Touchscreen_LCD-SoldP_Front.gtp	: Top/Front Solder Paste Stencil

	Opennect-Touchscreen_LCD-SilkS_Front.gto	: Top/Front Layer Silkscreen
	Opennect-Touchscreen_LCD-Mask_Front.gts		: Top/Front Layer Solder Mask
	Opennect-Touchscreen_LCD-Front.gtl		: Top/Front Copper Layer
	Opennect-Touchscreen_LCD-Back.gbl		: Bottom/Back Copper Layer
	Opennect-Touchscreen_LCD-Mask_Back.gbs		: Bottom/Back Layer Solder Mask
	Opennect-Touchscreen_LCD-PCB_Edges.oln		: PCB Edge Outline

Drill File: Opennect-Touchscreen_LCD.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : None (Keep Zeros)
	Type : ASCII
	Drill Holes (Pads and Vias): 133
	Notes:  - No axis mirroring and only standard vias
		- All holes are plated
		- Minimal Header
