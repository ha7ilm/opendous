File Format: Gerber RS-274-X
Plot Origin: Absolute

	Upconverter-100MHz-ADE-SoldP_Front.gtp	: Top/Front Layer Solder Paste Stencil

	Upconverter-100MHz-ADE-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Upconverter-100MHz-ADE-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Upconverter-100MHz-ADE-Front.gtl	: Top/Front Copper Layer
	Upconverter-100MHz-ADE-Back.gbl		: Bottom/Back Copper Layer
	Upconverter-100MHz-ADE-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask

	Upconverter-100MHz-ADE-PCB_Edges.gbr	: PCB Edge Outline


Drill File: Upconverter-100MHz-ADE.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Suppress Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 408
	Notes:	- No axis mirroring
		- Standard Vias Only
		- All holes are plated
